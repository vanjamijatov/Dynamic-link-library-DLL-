﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrimerDLL
{
    public class MathExecutor
    {
        public static double CalculateMax(List<double> objects)
        {
            return objects.Max();
        }

        public static double CalculateMin(List<double> objects)
        {
            return objects.Min();
        }

        public static double CalculateAvg(List<double> objects)
        {
            return objects.Average();
        }

        public static double CalculateSum(List<double> objects)
        {
            return objects.Sum();
        }
    }
}
